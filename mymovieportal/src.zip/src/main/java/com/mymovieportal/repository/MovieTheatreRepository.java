package com.mymovieportal.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.mymovieportal.model.MovieTheatre;

public interface MovieTheatreRepository extends JpaRepository<MovieTheatre, Integer>{

}