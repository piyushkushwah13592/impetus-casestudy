package com.mymovieportal.mymovieportal.serviceImpl;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertSame;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyLong;
import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.mymovieportal.dao.CityDAO;
import com.mymovieportal.dto.CityDTO;
import com.mymovieportal.exception.CityException;
import com.mymovieportal.model.City;
import com.mymovieportal.repository.CityRepository;
import com.mymovieportal.service.CityService;
import com.mymovieportal.service.impl.CityServiceImpl;

public class CityServiceImplUnitTest {

    @InjectMocks
    private CityService cityService = new CityServiceImpl();

    @Mock
    private CityDAO cityDao;

    @Mock
    private CityRepository cityRepository;

    private static String CITYID = "c01";

    @Before
    public void initMocks() {
        MockitoAnnotations.initMocks(this);
    }

    @Test
    public void testGetCity() throws CityException {
        City city = new City();
        // city.setCityId("c01");
        city.setCityName("Indore");
        when(cityDao.getCity(anyLong())).thenReturn(city);
        City city2 = cityService.getCity(city.getCityId());
        assertEquals(city2.getCityName(), city.getCityName());
    }

   /* @Test(expected = CityException.class)
    public void testGetCityInvalid() throws CityException {
        when(cityDao.getCity(CITYID)).thenReturn(null);
        City city2 = cityService.getCity(CITYID);
        assertNull(city2);
    }
*/
    @Test
    public void testGetCities() {
        List<City> cities = new ArrayList<>();
        when(cityDao.getCities()).thenReturn(cities);
        List<City> cityList = cityService.getCities();
        assertNotNull(cityList);
    }

    @Test
    public void testGetCityNameOnly() throws CityException {
        String cityName = "Indore";
        when(cityDao.getCityNameOnly(anyString())).thenReturn(cityName);
        String cityN = cityService.getCityNameOnly("c01");
        assertSame(cityN, cityName);
    }

    @Test(expected = CityException.class)
    public void testGetCityNameOnlyInvalid() throws CityException {
        when(cityDao.getCityNameOnly(anyString())).thenReturn(null);
        String cityN = cityService.getCityNameOnly("00");
        assertNull(cityN);
    }

    @Test
    public void testInsertCityForExistingCity() throws CityException {
        City city = new City();
        when(cityRepository.findByCityName(anyString())).thenReturn(city);
        City city1 = cityService.insertCity(new CityDTO());
        assertEquals(city.getCityStatus(), "active");
        assertNotNull(city1);
    }

    @Test
    public void testInsertCityForNonExistingCity() throws CityException {
        when(cityRepository.findByCityName(anyString())).thenReturn(null);
        List<String> cityIds = new ArrayList<>();
        cityIds.add("c01");
        cityIds.add("c02");
        when(cityRepository.getCityIds()).thenReturn(cityIds);
        City city = new City();
        city.setCityStatus("active");
        when(cityRepository.save(any(City.class))).thenReturn(city);
        City city1 = cityService.insertCity(new CityDTO());
        assertEquals(city1.getCityStatus(), "active");
    }

    @Test(expected = CityException.class)
    public void testDeleteCityForNonExistingCity() throws CityException {
        when(cityRepository.findByCityNameAndCityStatus(anyString(), anyString())).thenReturn(null);
        City city1 = cityService.deleteCity(new CityDTO());
        assertNull(city1);
    }

    @Test
    public void testDeleteCityForExistingCity() throws CityException {
        when(cityRepository.findByCityNameAndCityStatus(anyString(), anyString())).thenReturn(new City());
        City city = new City();
        city.setCityStatus("inactive");
        when(cityRepository.save(any(City.class))).thenReturn(city);
        City city1 = cityService.deleteCity(new CityDTO());
        assertEquals(city1.getCityStatus(), "inactive");

    }
}
