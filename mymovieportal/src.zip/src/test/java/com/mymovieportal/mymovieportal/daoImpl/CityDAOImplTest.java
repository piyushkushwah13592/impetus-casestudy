package com.mymovieportal.mymovieportal.daoImpl;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.mymovieportal.dao.CityDAO;
import com.mymovieportal.dao.impl.CityDAOImpl;
import com.mymovieportal.model.City;

public class CityDAOImplTest {

    @InjectMocks
    private CityDAO cityDAO = new CityDAOImpl();

    @Mock
    private SessionFactory sessionFactory;

    private Session session;

    private Query query;

    @Before
    public void initMocks() {
        MockitoAnnotations.initMocks(this);
        session = mock(Session.class);

        when(sessionFactory.getCurrentSession()).thenReturn(session);

    }

    @Test
    public void testGetCity() {

        City city = new City();
        city.setCityId("c01");
        city.setCityName("Inodre");

        when(session.get(City.class, "c01")).thenReturn(city);

        City city1 = cityDAO.getCity("c01");
        assertEquals(city1.getCityName(), city.getCityName());
    }

    @Test
    public void testGetCityInvalid() {

        City city = new City();
        city.setCityId("c01");
        city.setCityName("Inodre");

        when(session.get(City.class, "c010")).thenReturn(null);

        City city1 = cityDAO.getCity("c01");
        assertEquals(city1, null);
    }

    @Test
    public void testGetCities() {

        List<City> cityList = new ArrayList<>();
        City city = new City();
        city.setCityId("c01");
        city.setCityName("Inodre");

        cityList.add(city);

        query = mock(Query.class);
        when(query.list()).thenReturn(cityList);
        when(session.createQuery(anyString())).thenReturn(query);

        List<City> cityList2 = cityDAO.getCities();
        assertTrue(cityList2.size() == 1);

    }

    @Test
    public void testGetCityNameOnly() {
        City city = new City();
        city.setCityId("c01");
        city.setCityName("Inodre");

        when(session.get(City.class, "c01")).thenReturn(city);

        String cityName = cityDAO.getCityNameOnly("c01");
        assertEquals(cityName, city.getCityName());
    }

    @Test
    public void testGetCityNameOnlyInvalid() {
        City city = new City();
        city.setCityId("c01");
        city.setCityName("Inodre");

        when(session.get(City.class, "c01o")).thenReturn(null);

        String cityName = cityDAO.getCityNameOnly("c01");
        assertEquals(cityName, null);
    }
}
