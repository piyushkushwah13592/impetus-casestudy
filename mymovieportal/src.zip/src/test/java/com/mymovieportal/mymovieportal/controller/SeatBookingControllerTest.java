package com.mymovieportal.mymovieportal.controller;

import static org.junit.Assert.assertEquals;

import org.json.JSONException;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.context.embedded.LocalServerPort;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit4.SpringRunner;

import com.mymovieportal.MymovieportalApplication;
import com.mymovieportal.model.SeatBooking;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = MymovieportalApplication.class, webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
public class SeatBookingControllerTest {

    @LocalServerPort
    private int port;

    TestRestTemplate restTemplate = new TestRestTemplate();

    HttpHeaders headers = new HttpHeaders();

    @Test
    public void testGetSeatName() throws JSONException {
        SeatBooking seatBooking = new SeatBooking();
        seatBooking.setSbCityId("c01");
        seatBooking.setSbMovieId("m01");
        seatBooking.setSbTheatreId("t01");
        seatBooking.setSbDate("2018-12-16");
        seatBooking.setSbShowTime("21:00:00");
        HttpEntity<SeatBooking> entity = new HttpEntity<>(seatBooking, headers);
        ResponseEntity<String> response = restTemplate.exchange(
            createURLWithPort("/mymovieportal/seatbooking/getSeatName"), HttpMethod.POST, entity, String.class);
        assertEquals(HttpStatus.OK, response.getStatusCode());
    }

    @Test
    public void testGetSeatNameError() throws JSONException {
        SeatBooking seatBooking = new SeatBooking();
        seatBooking.setSbCityId("c00");
        seatBooking.setSbMovieId("m01");
        seatBooking.setSbTheatreId("t01");
        seatBooking.setSbDate("2018-05-18");
        seatBooking.setSbShowTime("10:53:38");

        HttpEntity<SeatBooking> entity = new HttpEntity<>(seatBooking, headers);

        ResponseEntity<String> response = restTemplate.exchange(
            createURLWithPort("/mymovieportal/seatbooking/getSeatName"), HttpMethod.POST, entity, String.class);

        assertEquals(HttpStatus.NOT_FOUND, response.getStatusCode());

    }

    @Test
    public void testGetSeatNameNoCityId() throws JSONException {
        SeatBooking seatBooking = new SeatBooking();
        seatBooking.setSbCityId(" ");
        seatBooking.setSbMovieId("m01");
        seatBooking.setSbTheatreId("t01");
        seatBooking.setSbDate("2018-05-18");
        seatBooking.setSbShowTime("10:53:38");

        HttpEntity<SeatBooking> entity = new HttpEntity<>(seatBooking, headers);

        ResponseEntity<String> response = restTemplate.exchange(
            createURLWithPort("/mymovieportal/seatbooking/getSeatName"), HttpMethod.POST, entity, String.class);

        assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());

    }

    @Test
    public void testGetSeatNameSpaceCityId() throws JSONException {
        SeatBooking seatBooking = new SeatBooking();
        seatBooking.setSbMovieId("m01");
        seatBooking.setSbTheatreId("t01");
        seatBooking.setSbDate("2018-05-18");
        seatBooking.setSbShowTime("10:53:38");

        HttpEntity<SeatBooking> entity = new HttpEntity<>(seatBooking, headers);

        ResponseEntity<String> response = restTemplate.exchange(
            createURLWithPort("/mymovieportal/seatbooking/getSeatName"), HttpMethod.POST, entity, String.class);

        assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());

    }

    @Test
    public void testGetSeatNameNoTheatreId() throws JSONException {
        SeatBooking seatBooking = new SeatBooking();
        seatBooking.setSbCityId("c01");
        seatBooking.setSbMovieId("m01");
        seatBooking.setSbDate("2018-05-18");
        seatBooking.setSbShowTime("10:53:38");

        HttpEntity<SeatBooking> entity = new HttpEntity<>(seatBooking, headers);

        ResponseEntity<String> response = restTemplate.exchange(
            createURLWithPort("/mymovieportal/seatbooking/getSeatName"), HttpMethod.POST, entity, String.class);

        assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());

    }

    @Test
    public void testGetSeatNameSpaceTheatreId() throws JSONException {
        SeatBooking seatBooking = new SeatBooking();
        seatBooking.setSbMovieId("m01");
        seatBooking.setSbCityId("c01");
        seatBooking.setSbTheatreId("  ");
        seatBooking.setSbDate("2018-05-18");
        seatBooking.setSbShowTime("10:53:38");

        HttpEntity<SeatBooking> entity = new HttpEntity<>(seatBooking, headers);

        ResponseEntity<String> response = restTemplate.exchange(
            createURLWithPort("/mymovieportal/seatbooking/getSeatName"), HttpMethod.POST, entity, String.class);

        assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());

    }

    @Test
    public void testGetSeatNameNoMovieId() throws JSONException {
        SeatBooking seatBooking = new SeatBooking();
        seatBooking.setSbCityId("c01");
        seatBooking.setSbMovieId("m01");
        seatBooking.setSbDate("2018-05-18");
        seatBooking.setSbShowTime("10:53:38");

        HttpEntity<SeatBooking> entity = new HttpEntity<>(seatBooking, headers);

        ResponseEntity<String> response = restTemplate.exchange(
            createURLWithPort("/mymovieportal/seatbooking/getSeatName"), HttpMethod.POST, entity, String.class);

        assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());

    }

    @Test
    public void testGetSeatNameSpaceMovieId() throws JSONException {
        SeatBooking seatBooking = new SeatBooking();
        seatBooking.setSbMovieId("  ");
        seatBooking.setSbCityId("c01");
        seatBooking.setSbTheatreId("t01");
        seatBooking.setSbDate("2018-05-18");
        seatBooking.setSbShowTime("10:53:38");

        HttpEntity<SeatBooking> entity = new HttpEntity<>(seatBooking, headers);

        ResponseEntity<String> response = restTemplate.exchange(
            createURLWithPort("/mymovieportal/seatbooking/getSeatName"), HttpMethod.POST, entity, String.class);

        assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());

    }

    // @Ignore
    @Test
    public void testSetSeatName() throws JSONException {
        SeatBooking[] seatBooking = new SeatBooking[1];
        seatBooking[0] = new SeatBooking();
        seatBooking[0].setSbCityId("c01");
        seatBooking[0].setSbTheatreId("t01");
        seatBooking[0].setSbMovieId("m01");
        seatBooking[0].setSbShowTime("18:00:00");
        seatBooking[0].setSeatName("Z3");
        seatBooking[0].setSbDate("2018-07-19");
        seatBooking[0].setSbUserId(1);

        HttpEntity<SeatBooking[]> entity = new HttpEntity<>(seatBooking, headers);

        ResponseEntity<String> response = restTemplate.exchange(
            createURLWithPort("/mymovieportal/seatbooking/setSeatName"), HttpMethod.POST, entity, String.class);

        assertEquals(HttpStatus.OK, response.getStatusCode());

    }

    // @Ignore
    @Test
    public void testSetSeatNameInValidData() throws JSONException {
        SeatBooking[] seatBooking = new SeatBooking[0];
        HttpEntity<SeatBooking[]> entity = new HttpEntity<>(seatBooking, headers);

        ResponseEntity<String> response = restTemplate.exchange(
            createURLWithPort("/mymovieportal/seatbooking/setSeatName"), HttpMethod.POST, entity, String.class);

        assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());

    }

    @Test
    public void testGetUserHistory() throws JSONException {

        HttpEntity<String> entity = new HttpEntity<>(null, headers);

        ResponseEntity<String> response = restTemplate.exchange(
            createURLWithPort("/mymovieportal/seatbooking/getUserHistory/1"), HttpMethod.GET, entity, String.class);

        assertEquals(HttpStatus.OK, response.getStatusCode());

    }

    @Test
    public void testGetUserHistoryInvalidId() throws JSONException {

        HttpEntity<String> entity = new HttpEntity<>(null, headers);

        ResponseEntity<String> response = restTemplate.exchange(
            createURLWithPort("/mymovieportal/seatbooking/getUserHistory/101"), HttpMethod.GET, entity, String.class);

        assertEquals(HttpStatus.NOT_FOUND, response.getStatusCode());

    }

    @Test
    public void testGetUserHistoryInvalidId2() throws JSONException {

        HttpEntity<String> entity = new HttpEntity<>(null, headers);

        ResponseEntity<String> response = restTemplate.exchange(
            createURLWithPort("/mymovieportal/seatbooking/getUserHistory/-1"), HttpMethod.GET, entity, String.class);

        assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());

    }

    @Test
    public void testCancelTicket() throws JSONException {

        HttpEntity<String> entity = new HttpEntity<>(null, headers);

        ResponseEntity<String> response = restTemplate.exchange(
            createURLWithPort("/mymovieportal/seatbooking/cancelTicket/1"), HttpMethod.GET, entity, String.class);

        assertEquals(HttpStatus.OK, response.getStatusCode());

    }

    @Test
    public void testCancelTicketInvalidId() throws JSONException {

        HttpEntity<String> entity = new HttpEntity<>(null, headers);

        ResponseEntity<String> response = restTemplate.exchange(
            createURLWithPort("/mymovieportal/seatbooking/cancelTicket/101"), HttpMethod.GET, entity, String.class);

        assertEquals(HttpStatus.NOT_FOUND, response.getStatusCode());

    }

    @Test
    public void testCancelTicketInvalidId2() throws JSONException {

        HttpEntity<String> entity = new HttpEntity<>(null, headers);

        ResponseEntity<String> response = restTemplate.exchange(
            createURLWithPort("/mymovieportal/seatbooking/cancelTicket/-1"), HttpMethod.GET, entity, String.class);

        assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());

    }


    @Test
    public void testGoToCancelTicket() throws JSONException {

        HttpEntity<String> entity = new HttpEntity<>(null, headers);

        ResponseEntity<String> response = restTemplate.exchange(
            createURLWithPort("/mymovieportal/seatbooking/goToCancelTicket/1"), HttpMethod.GET, entity, String.class);

        assertEquals(HttpStatus.OK, response.getStatusCode());

    }


    @Test
    public void testGoToCancelTicketInvalid() {

        HttpEntity<String> entity = new HttpEntity<>(null, headers);

        ResponseEntity<String> response = restTemplate.exchange(
            createURLWithPort("/mymovieportal/seatbooking/goToCancelTicket/1010101"), HttpMethod.GET, entity,
            String.class);

        assertEquals(HttpStatus.NOT_FOUND, response.getStatusCode());
    }

    @Test
    public void testGoToCancelTicketInvalid2() {

        HttpEntity<String> entity = new HttpEntity<>(null, headers);

        ResponseEntity<String> response = restTemplate.exchange(
            createURLWithPort("/mymovieportal/seatbooking/goToCancelTicket/-1"), HttpMethod.GET, entity,
            String.class);

        assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
    }

    private String createURLWithPort(String uri) {
        return "http://localhost:" + port + uri;
    }
}
