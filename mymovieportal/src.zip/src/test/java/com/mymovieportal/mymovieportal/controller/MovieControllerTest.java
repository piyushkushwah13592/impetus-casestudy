package com.mymovieportal.mymovieportal.controller;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import org.json.JSONException;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.skyscreamer.jsonassert.JSONAssert;
import org.springframework.boot.context.embedded.LocalServerPort;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit4.SpringRunner;

import com.mymovieportal.MymovieportalApplication;
import com.mymovieportal.dto.MovieTheatreDTO;
import com.mymovieportal.dto.ResultDTO;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = MymovieportalApplication.class,
    webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
public class MovieControllerTest {

    @LocalServerPort
    private int port;

    TestRestTemplate restTemplate = new TestRestTemplate();

    HttpHeaders headers = new HttpHeaders();

    @Test
    public void testGetCities() {

        HttpEntity<String> entity = new HttpEntity<>(null, headers);

        ResponseEntity<String> response = restTemplate.exchange(
            createURLWithPort("/mymovieportal/movie/getMovies"),
            HttpMethod.GET, entity, String.class);

        assertEquals(HttpStatus.OK, response.getStatusCode());

    }

    @Test
    public void testGetMovie() throws JSONException {

        HttpEntity<String> entity = new HttpEntity<>(null, headers);

        ResponseEntity<String> response = restTemplate.exchange(
            createURLWithPort("/mymovieportal/movie/getMovie/m01"),
            HttpMethod.GET, entity, String.class);

        String expected = "{movieId:m01,movieName:DDLJ,moviePrice:\"150\",movieStatus:active}";

        JSONAssert.assertEquals(expected, response.getBody(), true);

    }

    @Test
    public void testGetMovieInvalidId() throws JSONException {

        HttpEntity<String> entity = new HttpEntity<>(null, headers);

        ResponseEntity<String> response = restTemplate.exchange(
            createURLWithPort("/mymovieportal/movie/getMovie/m00"),
            HttpMethod.GET, entity, String.class);

        assertEquals(HttpStatus.NOT_FOUND, response.getStatusCode());

    }

    @Test
    public void testGetMovieForSpacesOnly() throws JSONException {

        HttpEntity<String> entity = new HttpEntity<>(null, headers);

        ResponseEntity<String> response = restTemplate.exchange(
            createURLWithPort("/mymovieportal/movie/getMovie/   "),
            HttpMethod.GET, entity, String.class);

        assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());

    }

    @Test
    public void testGetMovieByTheatreId() throws JSONException {

        HttpEntity<String> entity = new HttpEntity<>(null, headers);

        ResponseEntity<String> response = restTemplate.exchange(
            createURLWithPort("/mymovieportal/movie/getMovies/t01"),
            HttpMethod.GET, entity, String.class);

        assertEquals(HttpStatus.CREATED, response.getStatusCode());

    }

    @Test
    public void testGetMovieByInvalidTheatreId() throws JSONException {

        HttpEntity<String> entity = new HttpEntity<>(null, headers);

        ResponseEntity<String> response = restTemplate.exchange(
            createURLWithPort("/mymovieportal/movie/getMovies/t00"),
            HttpMethod.GET, entity, String.class);

        assertEquals(HttpStatus.NOT_FOUND, response.getStatusCode());

    }

    @Test
    public void testGetMovieByTheatreIdForSpacesOnly() throws JSONException {

        HttpEntity<String> entity = new HttpEntity<>(null, headers);

        ResponseEntity<String> response = restTemplate.exchange(
            createURLWithPort("/mymovieportal/movie/getMovies/   "),
            HttpMethod.GET, entity, String.class);

        assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());

    }

    @Test
    public void testGetShowtime() {

        MovieTheatreDTO movieTheatreDTO = new MovieTheatreDTO();
        movieTheatreDTO.setMtTheatreId("t01");
        movieTheatreDTO.setMtMovieId("m01");

        HttpEntity<MovieTheatreDTO> entity = new HttpEntity<>(movieTheatreDTO, headers);

        ResponseEntity<String> response = restTemplate.exchange(
            createURLWithPort("/mymovieportal/movie/getShowtime"),
            HttpMethod.POST, entity, String.class);

        assertEquals(HttpStatus.CREATED, response.getStatusCode());
    }

    @Test
    public void testGetShowtimeForNoMovieId() {

        MovieTheatreDTO movieTheatreDTO = new MovieTheatreDTO();
        movieTheatreDTO.setMtTheatreId("t01");

        HttpEntity<MovieTheatreDTO> entity = new HttpEntity<>(movieTheatreDTO, headers);

        ResponseEntity<String> response = restTemplate.exchange(
            createURLWithPort("/mymovieportal/movie/getShowtime"),
            HttpMethod.POST, entity, String.class);

        assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
    }

    @Test
    public void testGetShowtimeForNoTheatreId() {

        MovieTheatreDTO movieTheatreDTO = new MovieTheatreDTO();
        movieTheatreDTO.setMtMovieId("m01");

        HttpEntity<MovieTheatreDTO> entity = new HttpEntity<>(movieTheatreDTO, headers);

        ResponseEntity<String> response = restTemplate.exchange(
            createURLWithPort("/mymovieportal/movie/getShowtime"),
            HttpMethod.POST, entity, String.class);

        assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
    }

    @Test
    public void testGetShowtimeForSpacesTheatreId() {

        MovieTheatreDTO movieTheatreDTO = new MovieTheatreDTO();
        movieTheatreDTO.setMtMovieId("m01");
        movieTheatreDTO.setMtTheatreId("  ");

        HttpEntity<MovieTheatreDTO> entity = new HttpEntity<>(movieTheatreDTO, headers);

        ResponseEntity<String> response = restTemplate.exchange(
            createURLWithPort("/mymovieportal/movie/getShowtime"),
            HttpMethod.POST, entity, String.class);

        assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
    }

    @Test
    public void testGetShowtimeForSpacesMovieId() {

        MovieTheatreDTO movieTheatreDTO = new MovieTheatreDTO();
        movieTheatreDTO.setMtMovieId(" ");
        movieTheatreDTO.setMtTheatreId("t01");

        HttpEntity<MovieTheatreDTO> entity = new HttpEntity<>(movieTheatreDTO, headers);

        ResponseEntity<String> response = restTemplate.exchange(
            createURLWithPort("/mymovieportal/movie/getShowtime"),
            HttpMethod.POST, entity, String.class);

        assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
    }

    @Test
    public void testGetShowtimeError() {

        MovieTheatreDTO movieTheatreDTO = new MovieTheatreDTO();
        movieTheatreDTO.setMtMovieId("m00");
        movieTheatreDTO.setMtTheatreId("t00");

        HttpEntity<MovieTheatreDTO> entity = new HttpEntity<>(movieTheatreDTO, headers);

        ResponseEntity<String> response = restTemplate.exchange(
            createURLWithPort("/mymovieportal/movie/getShowtime"),
            HttpMethod.POST, entity, String.class);

        assertEquals(HttpStatus.NOT_FOUND, response.getStatusCode());
    }

    @Test
    public void testGetDiscount() throws JSONException {

        MovieTheatreDTO movieTheatreDTO = new MovieTheatreDTO();
        movieTheatreDTO.setMtMovieId("m01");
        movieTheatreDTO.setMtTheatreId("t01");

        HttpEntity<MovieTheatreDTO> entity = new HttpEntity<>(movieTheatreDTO, headers);

        ResponseEntity<String> response = restTemplate.exchange(
            createURLWithPort("/mymovieportal/movie/getDiscount"),
            HttpMethod.POST, entity, String.class);

        assertEquals("10", response.getBody());
    }

    @Test
    public void testGetDiscountForNoMovieId() throws JSONException {

        MovieTheatreDTO movieTheatreDTO = new MovieTheatreDTO();
        movieTheatreDTO.setMtTheatreId("t01");

        HttpEntity<MovieTheatreDTO> entity = new HttpEntity<>(movieTheatreDTO, headers);

        ResponseEntity<String> response = restTemplate.exchange(
            createURLWithPort("/mymovieportal/movie/getDiscount"),
            HttpMethod.POST, entity, String.class);

        assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
    }

    @Test
    public void testGetDiscountForNoTheatreId() throws JSONException {

        MovieTheatreDTO movieTheatreDTO = new MovieTheatreDTO();
        movieTheatreDTO.setMtMovieId("m01");

        HttpEntity<MovieTheatreDTO> entity = new HttpEntity<>(movieTheatreDTO, headers);

        ResponseEntity<String> response = restTemplate.exchange(
            createURLWithPort("/mymovieportal/movie/getDiscount"),
            HttpMethod.POST, entity, String.class);

        assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
    }

    @Test
    public void testGetDiscountForSpaceTheatreId() throws JSONException {

        MovieTheatreDTO movieTheatreDTO = new MovieTheatreDTO();
        movieTheatreDTO.setMtMovieId("m01");
        movieTheatreDTO.setMtTheatreId(" ");

        HttpEntity<MovieTheatreDTO> entity = new HttpEntity<>(movieTheatreDTO, headers);

        ResponseEntity<String> response = restTemplate.exchange(
            createURLWithPort("/mymovieportal/movie/getDiscount"),
            HttpMethod.POST, entity, String.class);

        assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
    }

    @Test
    public void testGetDiscountForSpaceMovieId() throws JSONException {

        MovieTheatreDTO movieTheatreDTO = new MovieTheatreDTO();
        movieTheatreDTO.setMtMovieId(" ");
        movieTheatreDTO.setMtTheatreId("t01");

        HttpEntity<MovieTheatreDTO> entity = new HttpEntity<>(movieTheatreDTO, headers);

        ResponseEntity<String> response = restTemplate.exchange(
            createURLWithPort("/mymovieportal/movie/getDiscount"),
            HttpMethod.POST, entity, String.class);

        assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
    }

    @Test
    public void testGetDiscountForInvalidData() throws JSONException {
        MovieTheatreDTO movieTheatreDTO = new MovieTheatreDTO();
        movieTheatreDTO.setMtMovieId("m03");
        movieTheatreDTO.setMtTheatreId("t03");
        movieTheatreDTO.setMtShowtimeId("st03");

        HttpEntity<MovieTheatreDTO> entity = new HttpEntity<>(movieTheatreDTO, headers);

        ResponseEntity<String> response = restTemplate.exchange(
            createURLWithPort("/mymovieportal/movie/getDiscount"),
            HttpMethod.POST, entity, String.class);

        assertEquals(HttpStatus.NOT_FOUND, response.getStatusCode());
    }

    @Test
    public void testMovieInsertOperationThroughCSV() throws JSONException {
        ResultDTO resultDTO = new ResultDTO();
        resultDTO.setResult("D:\\InsertMovieForIntTest.csv");

        HttpEntity<ResultDTO> entity = new HttpEntity<>(resultDTO, headers);

        ResponseEntity<String> response = restTemplate.exchange(
            createURLWithPort("/mymovieportal/movie/movieOperationThroughCSV"),
            HttpMethod.POST, entity, String.class);

        assertTrue(response.getBody().contains("true"));

    }

    @Test
    public void testMovieDeleteOperationThroughCSV() throws JSONException {
        ResultDTO resultDTO = new ResultDTO();
        resultDTO.setResult("D:\\DeleteMovieForIntTest.csv");

        HttpEntity<ResultDTO> entity = new HttpEntity<>(resultDTO, headers);

        ResponseEntity<String> response = restTemplate.exchange(
            createURLWithPort("/mymovieportal/movie/movieOperationThroughCSV"),
            HttpMethod.POST, entity, String.class);

        assertTrue(response.getBody().contains("true"));

    }

    @Test
    public void testMovieOperationThroughCSVNoFile() throws JSONException {
        ResultDTO resultDTO = new ResultDTO();
        resultDTO.setResult("D:\\DeleteMovieForIntTest.hyut");

        HttpEntity<ResultDTO> entity = new HttpEntity<>(resultDTO, headers);

        ResponseEntity<String> response = restTemplate.exchange(
            createURLWithPort("/mymovieportal/movie/movieOperationThroughCSV"),
            HttpMethod.POST, entity, String.class);

        assertEquals(HttpStatus.NOT_FOUND, response.getStatusCode());
    }

    @Test
    public void testMovieInsertOperationThroughCSVFalseMovie() throws JSONException {
        ResultDTO resultDTO = new ResultDTO();
        resultDTO.setResult("D:\\DeleteMovieForIntTestFalseMovie.csv");

        HttpEntity<ResultDTO> entity = new HttpEntity<>(resultDTO, headers);

        ResponseEntity<String> response = restTemplate.exchange(
            createURLWithPort("/mymovieportal/movie/movieOperationThroughCSV"),
            HttpMethod.POST, entity, String.class);

        assertEquals(HttpStatus.NOT_FOUND, response.getStatusCode());

    }

    @Test
    public void testMovieOperationThroughCSVWithNullPath() throws JSONException {
        ResultDTO resultDTO = new ResultDTO();
        resultDTO.setResult(null);

        HttpEntity<ResultDTO> entity = new HttpEntity<>(resultDTO, headers);

        ResponseEntity<String> response = restTemplate.exchange(
            createURLWithPort("/mymovieportal/movie/movieOperationThroughCSV"),
            HttpMethod.POST, entity, String.class);

        assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());

    }

    @Test
    public void testMovieOperationThroughCSVWithSpacesPath() throws JSONException {
        ResultDTO resultDTO = new ResultDTO();
        resultDTO.setResult("   ");

        HttpEntity<ResultDTO> entity = new HttpEntity<>(resultDTO, headers);

        ResponseEntity<String> response = restTemplate.exchange(
            createURLWithPort("/mymovieportal/movie/movieOperationThroughCSV"),
            HttpMethod.POST, entity, String.class);

        assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());

    }

    @Test
    public void testMovieInsertOperationThroughXML() throws JSONException {
        ResultDTO resultDTO = new ResultDTO();
        resultDTO.setResult("D:\\InsertMovieForIntTest.xml");

        HttpEntity<ResultDTO> entity = new HttpEntity<>(resultDTO, headers);

        ResponseEntity<String> response = restTemplate.exchange(
            createURLWithPort("/mymovieportal/movie/movieInsertOperationThroughXml"),
            HttpMethod.POST, entity, String.class);

        assertTrue(response.getBody().contains("true"));

        assertEquals(HttpStatus.CREATED, response.getStatusCode());

    }

    @Test
    public void testMovieInsertOperationThroughXMLWithNullPath() throws JSONException {
        ResultDTO resultDTO = new ResultDTO();
        resultDTO.setResult(null);

        HttpEntity<ResultDTO> entity = new HttpEntity<>(resultDTO, headers);

        ResponseEntity<String> response = restTemplate.exchange(
            createURLWithPort("/mymovieportal/movie/movieInsertOperationThroughXml"),
            HttpMethod.POST, entity, String.class);

        assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());

    }

    @Test
    public void testMovieInsertOperationThroughXMLWithSpacesPath() throws JSONException {
        ResultDTO resultDTO = new ResultDTO();
        resultDTO.setResult("   ");

        HttpEntity<ResultDTO> entity = new HttpEntity<>(resultDTO, headers);

        ResponseEntity<String> response = restTemplate.exchange(
            createURLWithPort("/mymovieportal/movie/movieInsertOperationThroughXml"),
            HttpMethod.POST, entity, String.class);

        assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());

    }

    @Test
    public void testMovieDeleteOperationThroughXML() throws JSONException {
        ResultDTO resultDTO = new ResultDTO();
        resultDTO.setResult("D:\\DeleteMovieForIntTest.xml");

        HttpEntity<ResultDTO> entity = new HttpEntity<>(resultDTO, headers);

        ResponseEntity<String> response = restTemplate.exchange(
            createURLWithPort("/mymovieportal/movie/movieDeleteOperationThroughXml"),
            HttpMethod.POST, entity, String.class);

        assertTrue(response.getBody().contains("true"));

        assertEquals(HttpStatus.CREATED, response.getStatusCode());

    }

    @Test
    public void testMovieDeleteOperationThroughXMLWithNullPath() throws JSONException {
        ResultDTO resultDTO = new ResultDTO();
        resultDTO.setResult(null);

        HttpEntity<ResultDTO> entity = new HttpEntity<>(resultDTO, headers);

        ResponseEntity<String> response = restTemplate.exchange(
            createURLWithPort("/mymovieportal/movie/movieDeleteOperationThroughXml"),
            HttpMethod.POST, entity, String.class);

        assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());

    }

    @Test
    public void testMovieDeleteOperationThroughXMLFalseMovie() throws JSONException {
        ResultDTO resultDTO = new ResultDTO();
        resultDTO.setResult("D:\\DeleteMovieForIntTestFalseMovie.xml");

        HttpEntity<ResultDTO> entity = new HttpEntity<>(resultDTO, headers);

        ResponseEntity<String> response = restTemplate.exchange(
            createURLWithPort("/mymovieportal/movie/movieDeleteOperationThroughXml"),
            HttpMethod.POST, entity, String.class);

        assertEquals(HttpStatus.NOT_FOUND, response.getStatusCode());

    }

    @Test
    public void testMovieDeleteOperationThroughXMLWithSpacesPath() throws JSONException {
        ResultDTO resultDTO = new ResultDTO();
        resultDTO.setResult("   ");

        HttpEntity<ResultDTO> entity = new HttpEntity<>(resultDTO, headers);

        ResponseEntity<String> response = restTemplate.exchange(
            createURLWithPort("/mymovieportal/movie/movieInsertOperationThroughXml"),
            HttpMethod.POST, entity, String.class);

        assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());

    }

  /*  @Test
    public void testWriteMovieSummaryIntoPdf() {
        ResultDTO resultDTO = new ResultDTO();
        resultDTO.setResult("D:\\MoviePDF.pdf");
        HttpEntity<ResultDTO> entity = new HttpEntity<>(resultDTO, headers);

        ResponseEntity<String> response = restTemplate.exchange(
            createURLWithPort("/mymovieportal/movie/writeMovieSummary"),
            HttpMethod.POST, entity, String.class);

        assertTrue(response.getBody().contains("true"));

        assertEquals(HttpStatus.CREATED, response.getStatusCode());
    }

    @Test
    public void testWriteMovieSummaryIntoPdfWithSpacesPath() throws JSONException {
        ResultDTO resultDTO = new ResultDTO();
        resultDTO.setResult("   ");

        HttpEntity<ResultDTO> entity = new HttpEntity<>(resultDTO, headers);

        ResponseEntity<String> response = restTemplate.exchange(
            createURLWithPort("/mymovieportal/movie/writeMovieSummary"),
            HttpMethod.POST, entity, String.class);

        assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());

    }

    @Test
    public void testWriteMovieSummaryIntoPdfWithNullPath() throws JSONException {
        ResultDTO resultDTO = new ResultDTO();
        resultDTO.setResult(null);

        HttpEntity<ResultDTO> entity = new HttpEntity<>(resultDTO, headers);

        ResponseEntity<String> response = restTemplate.exchange(
            createURLWithPort("/mymovieportal/movie/writeMovieSummary"),
            HttpMethod.POST, entity, String.class);

        assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());

    }*/

    @Test
    public void testWriteMovieSummaryIntoPdf2() {

        HttpEntity<String> entity = new HttpEntity<>(null, headers);

        ResponseEntity<String> response = restTemplate.exchange(
            createURLWithPort("/mymovieportal/movie/downloadPDF"),
            HttpMethod.GET, entity, String.class);

        assertEquals(HttpStatus.CREATED, response.getStatusCode());

    }
    private String createURLWithPort(String uri) {
        return "http://localhost:" + port + uri;
    }
}
