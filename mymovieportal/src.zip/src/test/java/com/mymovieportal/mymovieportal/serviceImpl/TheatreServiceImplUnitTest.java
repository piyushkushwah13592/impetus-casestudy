package com.mymovieportal.mymovieportal.serviceImpl;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertSame;
import static org.junit.Assert.assertTrue;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.mymovieportal.dto.TheatreDTO;
import com.mymovieportal.exception.CityException;
import com.mymovieportal.exception.TheatreException;
import com.mymovieportal.model.Theatre;
import com.mymovieportal.repository.CityRepository;
import com.mymovieportal.repository.TheatreRepository;
import com.mymovieportal.service.TheatreService;
import com.mymovieportal.service.impl.TheatreServiceImpl;

public class TheatreServiceImplUnitTest {

	@InjectMocks
	TheatreService theatreService = new TheatreServiceImpl();

	@Mock
	TheatreRepository theatreRepository;

	@Mock
	CityRepository cityRepository;

	@Before
	public void initMocks() {
		MockitoAnnotations.initMocks(this);
	}

	@Test
	public void testGetTheatre() throws TheatreException {
		Theatre theatre = new Theatre();
		theatre.setTheatreId("t01");
		theatre.setTheatreName("Inox");
		when(theatreRepository.findByTheatreId(anyString())).thenReturn(theatre);
		Theatre theatre2 = theatreService.getTheatre("t01");
		assertSame(theatre.getTheatreId(), theatre2.getTheatreId());
	}

	@Test(expected = TheatreException.class)
	public void testGetTheatreInvalid() throws TheatreException {
		when(theatreRepository.findByTheatreId(anyString())).thenReturn(null);
		Theatre theatre2 = theatreService.getTheatre("00");
		assertNull(theatre2);
	}

	@Test
	public void testGetTheatres() {
		List<Theatre> theatreList = new ArrayList<>();
		theatreList.add(new Theatre());
		theatreList.add(new Theatre());
		when(theatreRepository.findAll()).thenReturn(theatreList);
		List<Theatre> theatres = theatreService.getTheatres();
		assertNotNull(theatres);
	}

	@Test
	public void testTheatresByCity() throws CityException {
		List<String> cityIds = new ArrayList<>();
		cityIds.add("c01");
		cityIds.add("c02");
		when(cityRepository.getCityIds()).thenReturn(cityIds);
		List<Theatre> theatreList = new ArrayList<>();
		theatreList.add(new Theatre());
		theatreList.add(new Theatre());
		when(theatreRepository.getTheatresByCity(anyString())).thenReturn(theatreList);
		List<Theatre> theatres = theatreService.getTheatresByCity("c01");
		assertNotNull(theatres);
	}

	@Test(expected = CityException.class)
	public void testTheatresByCityInvalid() throws CityException {
		List<String> cityIds = new ArrayList<>();
		cityIds.add("c01");
		cityIds.add("c02");
		when(cityRepository.getCityIds()).thenReturn(cityIds);
		List<Theatre> theatreList = new ArrayList<>();
		when(theatreRepository.getTheatresByCity(anyString())).thenReturn(theatreList);
		List<Theatre> theatres = theatreService.getTheatresByCity("c00");
		assertTrue(theatres.size() == 0);
	}

	@Test
	public void testGetTheatreNameOnly() {
		String theatreName = "INOX";
		when(theatreRepository.getTheatreNameOnly(anyString())).thenReturn(theatreName);
		String theatreN = theatreService.getTheareNameOnly("t01");
		assertSame(theatreName, theatreN);
	}

	@Test
	public void testGetTheatreNameOnlyInvalid() {
		when(theatreRepository.getTheatreNameOnly(anyString())).thenReturn(null);
		String theatreN = theatreService.getTheareNameOnly("t01");
		assertNull(theatreN);
	}

	@Test
	public void testInsertTheatreForExistingMovie() {
		Theatre theatre = new Theatre();
		when(theatreRepository.findByTheatreName(anyString())).thenReturn(theatre);
		Theatre theatre1 = theatreService.insertTheatre(new TheatreDTO());
		assertEquals(theatre.getTheatreStatus(), "active");
		assertNotNull(theatre1);
	}

	@Test
	public void testInsertTheatreForNonExistingMovie() {
		when(theatreRepository.findByTheatreName(anyString())).thenReturn(null);
		List<String> theatreIds = new ArrayList<>();
		theatreIds.add("t01");
		theatreIds.add("t02");
		when(theatreRepository.getTheatreIds()).thenReturn(theatreIds);
		Theatre theatre = new Theatre();
		theatre.setTheatreStatus("active");
		when(theatreRepository.save(any(Theatre.class))).thenReturn(theatre);
		Theatre theatre1 = theatreService.insertTheatre(new TheatreDTO());
		assertEquals(theatre1.getTheatreStatus(), "active");
	}

	@Test
	public void testDeleteTheatreForExistingTheatre() throws TheatreException {
		when(theatreRepository.findByTheatreNameAndTheatreStatus(anyString(), anyString())).thenReturn(new Theatre());
		Theatre theatre = new Theatre();
		theatre.setTheatreStatus("inactive");
		when(theatreRepository.save(any(Theatre.class))).thenReturn(theatre);
		Theatre theatre1 = theatreService.deleteTheatre(new TheatreDTO());
		assertEquals(theatre1.getTheatreStatus(), "inactive");
	}

	@Test(expected=TheatreException.class)
	public void testDeleteTheatreForNonExistingTheatre() throws TheatreException {
		when(theatreRepository.findByTheatreNameAndTheatreStatus(anyString(), anyString())).thenReturn(null);
		Theatre theatre = theatreService.deleteTheatre(new TheatreDTO());
		assertNull(theatre);
	}

}
