package com.mymovieportal.mymovieportal.serviceImpl;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertSame;
import static org.junit.Assert.assertTrue;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.when;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.mymovieportal.dto.MovieDTO;
import com.mymovieportal.dto.MovieTheatreDTO;
import com.mymovieportal.exception.MovieException;
import com.mymovieportal.exception.TheatreException;
import com.mymovieportal.model.Movie;
import com.mymovieportal.repository.MovieRepository;
import com.mymovieportal.repository.ShowtimeRepository;
import com.mymovieportal.repository.TheatreRepository;
import com.mymovieportal.service.MovieService;
import com.mymovieportal.service.impl.MovieServiceImpl;

public class MovieServiceImplUnitTest {

	@InjectMocks
	MovieService movieService = new MovieServiceImpl();

	@Mock
	MovieRepository movieRepository;

	@Mock
	TheatreRepository theatreRepository;

	@Mock
	ShowtimeRepository showtimeRepository;

	@Before
	public void initMocks() {
		MockitoAnnotations.initMocks(this);
	}

	@Test
	public void testGetMovies() {
		List<Movie> movieList = new ArrayList<>();
		movieList.add(new Movie());
		movieList.add(new Movie());
		when(movieRepository.findAll()).thenReturn(movieList);
		List<Movie> movies = movieService.getMovies();
		assertNotNull(movies);
	}

	@Test
	public void testGetMovie() throws MovieException {
		Movie movie = new Movie();
		movie.setMovieId("m01");
		movie.setMovieName("Dhoom");
		when(movieRepository.findByMovieId(anyString())).thenReturn(movie);
		Movie movie2 = movieService.getMovie("m01");
		assertEquals(movie2.getMovieId(), "m01");
	}

	@Test(expected = MovieException.class)
	public void testGetCityInvalid() throws MovieException {
		when(movieRepository.findByMovieId(anyString())).thenReturn(null);
		Movie movie2 = movieService.getMovie("m00");
		assertNull(movie2);
	}

	@Test
	public void testGetMoviesByTheatre() throws TheatreException {
		List<Movie> movieList = new ArrayList<>();
		movieList.add(new Movie());
		movieList.add(new Movie());
		List<String> theatreIds = new ArrayList<>();
		theatreIds.add("t01");
		theatreIds.add("t02");
		when(theatreRepository.getTheatreIds()).thenReturn(theatreIds);
		when(movieRepository.getMoviesByTheatre(anyString())).thenReturn(movieList);
		List<Movie> movies = movieService.getMoviesByTheatre("t01");
		assertNotNull(movies);
	}

	@Test(expected = TheatreException.class)
	public void testGetMoviesByTheatreInvalid() throws TheatreException {
		List<Movie> movieList = new ArrayList<>();
		List<String> theatreIds = new ArrayList<>();
		theatreIds.add("t01");
		theatreIds.add("t02");
		when(theatreRepository.getTheatreIds()).thenReturn(theatreIds);
		when(movieRepository.getMoviesByTheatre(anyString())).thenReturn(movieList);
		List<Movie> movies = movieService.getMoviesByTheatre("00");
		assertEquals(movies, null);
	}

	@Test
	public void testGetShowTime() throws MovieException {
		List<String> timeList = new ArrayList<>();
		timeList.add("2018-04-14 19:08:12");
		timeList.add("2018-04-18 13:01:42");
		MovieTheatreDTO movieTheatreDTO = new MovieTheatreDTO();
		movieTheatreDTO.setMtMovieId("m01");
		movieTheatreDTO.setMtTheatreId("t01");
		when(showtimeRepository.getShowTime(anyString(), anyString())).thenReturn(timeList);
		List<String> times = movieService.getShowTime(movieTheatreDTO);
		assertNotNull(times);
	}

	@Test(expected = MovieException.class)
	public void testGetShowTimeInvalid() throws MovieException {
		List<String> timeList = new ArrayList<>();
		MovieTheatreDTO movieTheatreDTO = new MovieTheatreDTO();
		movieTheatreDTO.setMtMovieId("00");
		movieTheatreDTO.setMtTheatreId("00");
		when(showtimeRepository.getShowTime(anyString(), anyString())).thenReturn(timeList);
		List<String> times = movieService.getShowTime(movieTheatreDTO);
		assertTrue(times.size() == 0);
	}

	@Test
	public void testMovieNameOnly() {
		String movieName = "Dhoom";
		when(movieRepository.getMovieNameOnly(anyString())).thenReturn(movieName);
		String movieN = movieService.getMovieNameOnly("m01");
		assertSame(movieName, movieN);
	}

	@Test
	public void testGetDiscount() throws MovieException {
		List<Integer> discountList = new ArrayList<>();
		discountList.add(10);
		discountList.add(15);
		MovieTheatreDTO movieTheatreDTO = new MovieTheatreDTO();
		movieTheatreDTO.setMtMovieId("m01");
		movieTheatreDTO.setMtTheatreId("t01");
		when(movieRepository.getDiscount(anyString(), anyString())).thenReturn(discountList);
		int list = movieService.getDiscount(movieTheatreDTO);
		assertNotNull(list);
	}

	/**
	 * Test get discount invalid.
	 *
	 * @throws MovieException the movie exception
	 */
	@Test(expected = MovieException.class)
	public void testGetDiscountInvalid() throws MovieException {
		List<Integer> discountList = new ArrayList<>();
		MovieTheatreDTO movieTheatreDTO = new MovieTheatreDTO();
		movieTheatreDTO.setMtMovieId("00");
		movieTheatreDTO.setMtTheatreId("00");
		when(movieRepository.getDiscount(anyString(), anyString())).thenReturn(discountList);
		int list = movieService.getDiscount(movieTheatreDTO);
		assertTrue(list == 0);
	}

	@Test
	public void testInsertMovieForExistingMovie() {
		Movie movie = new Movie();
		movie.setMovieId("m01");
		movie.setMovieName("Baba");
		when(movieRepository.findByMovieName(anyString())).thenReturn(movie);
		MovieDTO movieDTO = new MovieDTO();
		movieDTO.setMovieId("m01");
		movieDTO.setMovieName("Baba");
		Movie movie1 = movieService.insertMovie(movieDTO);
		assertNotNull(movie1);
		assertEquals(movie.getMovieStatus(), "active");
	}

	@Test
	public void testInsertMovieForNonExistingMovie() {
		Movie movie = null;
		when(movieRepository.findByMovieName(anyString())).thenReturn(movie);
		List<String> movieIds = new ArrayList<>();
		movieIds.add("m01");
		movieIds.add("m02");
		when(movieRepository.getMovieIds()).thenReturn(movieIds);
		Movie movie2 = new Movie();
		movie2.setMovieId("m02");
		movie2.setMovieName("Bahubali");
		when(movieRepository.save(any(Movie.class))).thenReturn(movie2);
		Movie movie1 = movieService.insertMovie(new MovieDTO());
		assertNotNull(movie1);
		assertEquals(movie1.getMovieName(), "Bahubali");
	}

	@Test
	public void testDeleteMovieForExistingMovie() throws MovieException {
		Movie movie = new Movie();
		movie.setMovieId("m01");
		movie.setMovieName("Baba");
		movie.setMovieStatus("active");
		when(movieRepository.findByMovieNameAndMovieStatus(anyString(), anyString())).thenReturn(movie);
		when(movieRepository.save(any(Movie.class))).thenReturn(movie);
		MovieDTO movieDTO = new MovieDTO();
		movieDTO.setMovieId("m01");
		movieDTO.setMovieName("Baba");
		Movie movie1 = movieService.deleteMovie(new MovieDTO());
		assertEquals(movie1.getMovieStatus(), "inactive");

	}

	@Test(expected = MovieException.class)
	public void testDeleteMovieForNonExistingMovie() throws MovieException {
		when(movieRepository.findByMovieNameAndMovieStatus(anyString(), anyString())).thenReturn(null);
		Movie movie1 = movieService.deleteMovie(new MovieDTO());
		assertEquals(movie1, null);
	}

	@Test
	public void testAddMovieOperationThroughCSV() throws IOException, MovieException {
		String csvFile = "D://Files-UnitTest//InsertMovieForUnitTest.csv";
		BufferedReader br = new BufferedReader(new FileReader(csvFile));
		String operation = br.readLine();
		List<Movie> mList = new ArrayList<>();
		Movie movie1 = new Movie();
		movie1.setMovieId("m01");
		movie1.setMovieName("Lagan");
		movie1.setMoviePrice("150");
		movie1.setMovieStatus("inactive");
		Movie movie2 = new Movie();
		movie2.setMovieId("m02");
		movie2.setMovieName("DHOOM");
		movie2.setMoviePrice("200");
		movie2.setMovieStatus("active");
		Movie movie3 = new Movie();
		movie3.setMovieId("m03");
		movie3.setMovieName("DON");
		movie3.setMoviePrice("251");
		movie3.setMovieStatus("active");
		mList.add(movie1);
		mList.add(movie2);
		mList.add(movie3);
		Movie movie = new Movie();
		when(movieRepository.getAllMovies()).thenReturn(mList);
		when(movieRepository.save(movie)).thenReturn(new Movie());
		when(movieRepository.save(new ArrayList<Movie>())).thenReturn(new ArrayList());
		boolean result = movieService.movieOperationThroughCSV(br, operation);
		assertTrue(result);
	}

	@Test
	public void testDeleteMovieOperationThroughCSV() throws IOException, MovieException {
		String csvFile = "D://Files-UnitTest//DeleteMovieForUnitTest.csv";
		BufferedReader br = new BufferedReader(new FileReader(csvFile));
		String operation = br.readLine();
		Movie movie = new Movie();
		movie.setMovieId("m01");
		movie.setMovieName("Baba");
		movie.setMovieStatus("active");
		when(movieRepository.findByMovieNameAndMovieStatus(anyString(), anyString())).thenReturn(movie);
		when(movieRepository.save(any(Movie.class))).thenReturn(movie);
		boolean result = movieService.movieOperationThroughCSV(br, operation);
		assertTrue(result);
	}

	@Test(expected = MovieException.class)
	public void testDeleteMovieOperationThroughCSVForNonExistingMovie() throws IOException, MovieException {
		String csvFile = "D://Files-UnitTest//DeleteMovieForUnitTest.csv";
		BufferedReader br = new BufferedReader(new FileReader(csvFile));
		String operation = br.readLine();
		when(movieRepository.findByMovieNameAndMovieStatus(anyString(), anyString())).thenReturn(null);
		boolean result = movieService.movieOperationThroughCSV(br, operation);
		assertFalse(result);
	}

	@Test(expected = IOException.class)
	public void testDeleteMovieOperationThroughCSVForNonExistingFile() throws IOException, MovieException {
		String csvFile = "F:/DeleteMovieForUnitT.csv";
		BufferedReader br = new BufferedReader(new FileReader(csvFile));
		String operation = br.readLine();
		when(movieRepository.findByMovieNameAndMovieStatus(anyString(), anyString())).thenReturn(null);
		boolean result = movieService.movieOperationThroughCSV(br, operation);
		assertFalse(result);
	}

	@Test
	public void testAddMovieOperationThroughXML() {
		String filePath = "D://Files-UnitTest//InsertMovieForUnitTest.xml";
		File xmlFile = new File(filePath);
		List<Movie> mList = new ArrayList<>();
		Movie movie1 = new Movie();
		movie1.setMovieId("m01");
		movie1.setMovieName("Lagan");
		movie1.setMoviePrice("150");
		movie1.setMovieStatus("inactive");
		Movie movie2 = new Movie();
		movie2.setMovieId("m02");
		movie2.setMovieName("DHOOM");
		movie2.setMoviePrice("200");
		movie2.setMovieStatus("active");
		Movie movie3 = new Movie();
		movie3.setMovieId("m03");
		movie3.setMovieName("DON");
		movie3.setMoviePrice("251");
		movie3.setMovieStatus("active");
		mList.add(movie1);
		mList.add(movie2);
		mList.add(movie3);
		Movie movie = new Movie();
		when(movieRepository.getAllMovies()).thenReturn(mList);
		when(movieRepository.save(movie)).thenReturn(new Movie());
		when(movieRepository.save(new ArrayList<Movie>())).thenReturn(new ArrayList());
		boolean response = movieService.movieInsertOperationThroughXml(xmlFile);
		assertTrue(response);
	}

	@Test
	public void testDeleteMovieOperationThroughXML() throws MovieException {
		String filePath = "D://Files-UnitTest//DeleteMovieForUnitTest.xml";
		File xmlFile = new File(filePath);
		Movie movie = new Movie();
		movie.setMovieId("m01");
		movie.setMovieName("Baba");
		movie.setMovieStatus("active");
		when(movieRepository.findByMovieNameAndMovieStatus(anyString(), anyString())).thenReturn(movie);
		when(movieRepository.save(any(Movie.class))).thenReturn(movie);
		boolean response = movieService.movieDeleteOperationThroughXml(xmlFile);
		assertTrue(response);

	}

	@Test(expected = MovieException.class)
	public void testDeleteMovieOperationThroughXMLForNonExistingMovie() throws MovieException {
		String filePath = "D://Files-UnitTest//DeleteMovieForUnitTest.xml";
		File xmlFile = new File(filePath);
		when(movieRepository.findByMovieNameAndMovieStatus(anyString(), anyString())).thenReturn(null);
		boolean response = movieService.movieDeleteOperationThroughXml(xmlFile);
		assertFalse(response);

	}

	@Test
	public void testDeleteMovieOperationThroughXMLForNonExistingFile() throws MovieException {
		String filePath = "F:/DeleteMovieForUT.xml";
		File xmlFile = new File(filePath);
		when(movieRepository.findByMovieNameAndMovieStatus(anyString(), anyString())).thenReturn(null);
		boolean response = movieService.movieDeleteOperationThroughXml(xmlFile);
		assertFalse(response);

	}
}
